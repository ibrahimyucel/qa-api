Q2A BLOG POST PLUGIN 
=============

The Blog module allows registered users to maintain an online journal, or blog. Blogs are made up of individual blog entries. By default, the blog entries are displayed by creation time in descending order.

FEATURES OF THE BLOG POST PLUGIN
1. Article and Category management like Questions.
2. Uses default user interface/theme.
<img src="screenshots/bp_articles.png"/>

3. Admin panel for managing blog settings and categories.
<img src="screenshots/bp_admin.png"/>

4. It uses the editor selected by the admin in settings.
<img src="screenshots/bp_write.png"/>
