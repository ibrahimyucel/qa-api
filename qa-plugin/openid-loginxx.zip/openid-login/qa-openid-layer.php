<?php
/*
	Question2Answer by Gideon Greenspan and contributors
	http://www.question2answer.org/

	File: qa-plugin/facebook-login/qa-facebook-layer.php
	Description: Theme layer class for mouseover layer plugin


	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	More about this license: http://www.question2answer.org/license.php
*/

class qa_html_theme_layer extends qa_html_theme_base
{
	public function head_css()
	{
		qa_html_theme_base::head_css();

		if (strlen(qa_opt('facebook_app_id')) && strlen(qa_opt('facebook_app_secret'))) {
			$this->output('<link href="qa-plugin/openid-login/qa-open-login.css" rel="stylesheet" type="text/css">');
		}
	}
	
	public function head_script()
	{
		$this->output('<meta name="google-signin-scope" content="profile email">');
		$this->output('<meta name="google-signin-client_id" content="'.qa_opt('google_client_id').'">');
		$this->output('<script src="https://apis.google.com/js/platform.js" async defer></script>');	
		
		qa_html_theme_base::head_script();
	}
	
	function doctype() {
		parent::doctype();
		
		if(QA_FINAL_EXTERNAL_USERS) {
			return;
		}

		// check if logged in
		$handle = qa_get_logged_in_handle();
		if (isset($handle)) {
		
			if(qa_request() == '' && count($_GET) > 0) {
				// Check if we need to associate another provider
				$this->process_login();
			}
			
			// see if the account pages are accessed
			$tmpl = array( 'account', 'favorites' );
			$user_pages = array('user', 'user-wall', 'user-activity', 
				'user-questions', 'user-answers' );
			$logins_page = qa_request() == 'logins' && !qa_get('confirm');
			$urlhandle = qa_request_part(1);
			
			if ( in_array($this->template, $tmpl) || $logins_page || 
				(in_array($this->template, $user_pages) && $handle == $urlhandle) ) {
				// add a navigation item
				$this->content['navigation']['sub']['logins'] = array(
					'label' => qa_lang_html('openid/my_logins_nav'),
					'url' => qa_path_html('logins'),
					'selected' => $logins_page
				);
				return;
			}
			
		} else {
			$show_form = qa_opt('openid_hide_login_registration') == '1' ? true : false;
			$show_facebook = qa_opt('openid_facebook_login') == '1' ? true : false;
			$show_google = qa_opt('openid_google_login') == '1' ? true : false;
			$show_linkedin = qa_opt('openid_linkedin_login') == '1' ? true : false;
			
			// hide login/register links from navigation on any page
			
			/*if ($show_form) {
				//unset($this->content['navigation']['user']['login']);
				//unset($this->content['navigation']['user']['register']);
				
				$this->content['navigation']['user']['login'] = null;
				$this->content['navigation']['user']['register'] = null;
			}*/
		
			// then check if login/register pages are accessed
			$tmpl = array( 'register', 'login' );
			if ( !in_array($this->template, $tmpl) ) {
				return;
			}
			$tourl = qa_opt('site_url') . qa_get('to');
			
			$form = $this->content['form'];
			unset($this->content['form']);
			
			$this->content['custom'] = '<center><h3>'.qa_lang_html('openid/login_title').'</h3></center>';
			
			$this->content['custom'] .= '<div class="text-center mb-1">';
			
			if ($show_facebook) $this->content['custom'] .= '<a class="btn-fb btn-auth max-width-230px reset-text-transform"  href="'.qa_path_absolute('openid/facebook', array('to' => $tourl)).'"><img alt="Facebook logo" class="i-fa i-fa-sm btn-fb-icon" src="qa-plugin/openid-login/images/facebook.png" href="" />Login with Facebook</a>';
			
			if ($show_form) $this->content['custom'] .= '</div><div class="text-center mb-1">';
			
			if ($show_google) $this->content['custom'] .= '&nbsp;<a id="subscribe-google" class="btn-google btn-auth max-width-230px reset-text-transform" href="'.qa_path_absolute('openid/google', array('to' => $tourl)).'"><img alt="Google logo" class="i-fa i-fa-sm btn-fb-icon" src="qa-plugin/openid-login/images/google.png" />Login with Google</a>';
						
			if ($show_form) $this->content['custom'] .= '</div><div class="text-center mb-1">';
						
			if ($show_linkedin) $this->content['custom'] .= '&nbsp;<a id="subscribe-linkedin" class="btn-linkedin btn-auth max-width-230px reset-text-transform" href="'.qa_path_absolute('openid/linkedin', array('to' => $tourl)).'"><img alt="LinkedIn logo" class="i-fa i-fa-sm btn-fb-icon" src="qa-plugin/openid-login/images/linkedin.png" />Login with LinkedIn</a>';
			
			$this->content['custom'] .= '</div>';
			
			// show regular login/register form on those pages only
			if (!$show_form) $this->content['form'] = $form;
			
			/*if($this->content['form'] != null) {
				$this->content['custom'] = "<br /><br /><h1>$title</h1>{$this->content['custom']}";
			}*/
		
		}
	}

}
